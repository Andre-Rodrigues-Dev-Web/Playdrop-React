<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "playdr79_database";

$conn = new PDO("mysql:host=$host;dbname=" . $dbname, $user, $pass);